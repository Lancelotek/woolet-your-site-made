Woolet Brand Assets — Brand Book v1.0
=====================================

Files
-----
- logo-icon.png        Primary mark (gold "W" / bull, on Ink Black #0B0A09)
- logo.svg             Vector mark (Ink Black background)
- wordmark.svg         Wordmark "WOOLET" — Archivo Medium, tracking 0.32em, Cream on Ink
- favicon-16x16.png    Browser favicon 16×16
- favicon-32x32.png    Browser favicon 32×32
- apple-touch-icon.png 180×180 iOS home-screen icon

Color tokens
------------
Ink Black     #0B0A09
Panel         #16140F
Gold          #C2A05A   (≤ 10% of any screen)
Bright Gold   #D8B86A   (hover / emphasis)
Cream         #EFE9DF
Body Text     #C4BDAF

Typography
----------
Display — Newsreader (serif), Regular & Medium only
UI / Body — Archivo (sans)
Wordmark — Archivo Medium, uppercase, tracking 0.32em

Rules
-----
• Clear space ≥ cap-height on all sides.
• Minimum wordmark width 88 px on screen.
• Never stretch, recolour outside palette, or add effects.
• Never place the gold mark on a busy photo without a scrim.

© 2026 JAY23 LLC · woolet.co · Brand Book v1.0
